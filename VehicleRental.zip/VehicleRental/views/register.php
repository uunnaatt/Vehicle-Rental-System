<?php include '../includes/header.php'; ?>

<main class="auth-section">
    <div class="auth-container">
        <!-- Top Logo -->
        <div class="auth-logo">
            <img src="../assets/images/LOGO.png" alt="SAWARI" class="auth-logo-img">
        </div>

        <!-- Sign Up Form -->
        <div class="auth-form">
            <h1 class="auth-title">SIGN UP</h1>
            
            <form class="form" action="#" method="POST">
                <input type="text" class="form-input" placeholder="Enter Your Phone/Email" required>
                <input type="text" class="form-input" placeholder="FULL NAME" required>
                <input type="password" class="form-input" placeholder="Enter your password" required>
                
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember"> Remember Me
                    </label>
                    <a href="#" class="forgot-link">Forgot Password</a>
                </div>

                <button type="submit" class="btn-auth">LOGIN</button>
                <button type="submit" class="btn-auth btn-secondary">SIGNUP</button>
            </form>

            <!-- Divider -->
            <div class="divider">
                <span></span>
                <span class="divider-text">Or</span>
                <span></span>
            </div>

            <!-- Google Login -->
            <button class="btn-google">
                <img src="../assets/images/google-icon.png" alt="Google" class="google-icon">
                Continue with Google
            </button>

            <!-- Back Link -->
            <a href="index.php" class="back-link">Back</a>
        </div>
    </div>
</main>

</body>
</html>