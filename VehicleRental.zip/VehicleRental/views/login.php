<?php include '../includes/header.php'; ?>

<main class="auth-section">
    <div class="auth-container">
        <!-- Top Logo -->
        <div class="auth-logo">
            <img src="../assets/images/LOGO.png" alt="SAWARI" class="auth-logo-img">
        </div>

        <!-- Login Form -->
        <div class="auth-form">
            <h1 class="auth-title">WELCOME BACK<br>READY TO HIT THE ROAD?</h1>
            
            <form class="form" action="#" method="POST">
                <input type="text" class="form-input" placeholder="Enter Phone/Email" required>
                <input type="password" class="form-input" placeholder="Enter your password" required>
                
                <div class="form-options">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember"> Remember Me
                    </label>
                    <a href="#" class="forgot-link">Forgot Password</a>
                </div>

                <button type="submit" class="btn-auth">LOGIN</button>
                <button type="button" class="btn-auth btn-secondary" onclick="window.location.href='register.php'">SIGNUP</button>
            </form>

            <!-- Divider -->
            <div class="divider">
                <span></span>
                <span class="divider-text">Or</span>
                <span></span>
            </div>

            <!-- Google Login -->
            <button class="btn-google">
                <img src="../assets/images/google-icon.png" alt="Google" class="google-icon">
                Continue with Google
            </button>

            <!-- Back Link -->
            <a href="index.php" class="back-link">Back</a>
        </div>
    </div>
</main>

</body>
</html>